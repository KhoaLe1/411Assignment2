package com.csufcpsc411.hw2.model;

public class Courses {
    protected String mGrade;

    protected String mCourseID;

    public Courses(String courseID, String grade) {
        mCourseID = courseID;
        mGrade = grade;
    }

}
